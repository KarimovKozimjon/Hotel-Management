<?php

use App\Http\Controllers\API\AuthController;
use App\Http\Controllers\API\BookingController;
use App\Http\Controllers\API\ContactController;
use App\Http\Controllers\API\DashboardController;
use App\Http\Controllers\API\GuestController;
use App\Http\Controllers\API\GuestAuthController;
use App\Http\Controllers\API\PaymentController;
use App\Http\Controllers\API\RoomController;
use App\Http\Controllers\API\RoomTypeController;
use App\Http\Controllers\API\ServiceController;
use App\Http\Controllers\API\UserController;
use App\Http\Controllers\API\RoleController;
use App\Http\Controllers\API\ReviewController;
use App\Http\Controllers\API\NotificationController;
use App\Http\Controllers\API\InvoiceController;
use App\Http\Controllers\API\DiscountController;
use App\Http\Controllers\API\SecurityController;
use App\Http\Controllers\RoomImageController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// Public routes - Staff Login
Route::post('/register', [AuthController::class, 'register'])->middleware('throttle:register');
Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:login');

// Public routes - Guest Portal
Route::post('/guest/register', [GuestAuthController::class, 'register'])->middleware('throttle:register');
Route::post('/guest/login', [GuestAuthController::class, 'login'])->middleware('throttle:guest-login');

// Public routes - Room information for homepage
Route::get('/public/rooms', [RoomController::class, 'publicIndex']);
Route::get('/public/room-types', [RoomTypeController::class, 'publicIndex']);

// Public route - Contact form
Route::post('/contact', [ContactController::class, 'store']);

// Payment gateways removed. Only cash/card payments are supported.

// Protected routes
Route::middleware(['auth:sanctum', 'sanctum.user'])->group(function () {
    // Auth
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [AuthController::class, 'me']);

    // Two-Factor Auth (Admin only)
    Route::middleware('role:admin')->group(function () {
        Route::post('/2fa/setup', [AuthController::class, 'twoFactorSetup']);
        Route::post('/2fa/enable', [AuthController::class, 'twoFactorEnable']);
        Route::post('/2fa/disable', [AuthController::class, 'twoFactorDisable']);

        // Security
        Route::get('/security/login-attempts', [SecurityController::class, 'loginAttempts']);
        Route::get('/security/blocked-ips', [SecurityController::class, 'blockedIps']);
        Route::post('/security/blocked-ips', [SecurityController::class, 'blockIp']);
        Route::delete('/security/blocked-ips/{ip}', [SecurityController::class, 'unblockIp']);
    });

    // Dashboard - All authenticated users
    Route::get('/dashboard', [DashboardController::class, 'index']);
    Route::get('/dashboard/revenue', [DashboardController::class, 'revenue']);

    // Room Types - Admin and Manager
    Route::middleware('role:Admin,Manager')->group(function () {
        Route::apiResource('room-types', RoomTypeController::class)->except(['index', 'show']);
    });
    Route::get('/room-types', [RoomTypeController::class, 'index']);
    Route::get('/room-types/{id}', [RoomTypeController::class, 'show']);

    // Contact Messages - Admin and Manager
    Route::middleware('role:Admin,Manager')->group(function () {
        Route::get('/contact-messages', [ContactController::class, 'index']);
        Route::get('/contact-messages/unread-count', [ContactController::class, 'getUnreadCount']);
        Route::get('/contact-messages/{id}', [ContactController::class, 'show']);
        Route::delete('/contact-messages/{id}', [ContactController::class, 'destroy']);
        Route::post('/contact-messages/{id}/mark-as-read', [ContactController::class, 'markAsRead']);
    });

    // Rooms - Admin and Manager can modify, all can view
    Route::middleware('role:Admin,Manager')->group(function () {
        Route::post('/rooms', [RoomController::class, 'store']);
        Route::put('/rooms/{room}', [RoomController::class, 'update']);
        Route::delete('/rooms/{room}', [RoomController::class, 'destroy']);
    });
    Route::get('/rooms', [RoomController::class, 'index']);
    Route::get('/rooms/available', [RoomController::class, 'available']);
    Route::get('/rooms/{room}', [RoomController::class, 'show']);

    // Room Images - Admin can manage
    Route::middleware('role:Admin,Manager')->group(function () {
        Route::post('/rooms/{roomId}/images', [RoomImageController::class, 'store']);
        Route::put('/rooms/{roomId}/images/{imageId}', [RoomImageController::class, 'update']);
        Route::delete('/rooms/{roomId}/images/{imageId}', [RoomImageController::class, 'destroy']);
        Route::post('/rooms/{roomId}/images/{imageId}/set-primary', [RoomImageController::class, 'setPrimary']);
        Route::post('/rooms/{roomId}/images/reorder', [RoomImageController::class, 'reorder']);
    });
    Route::get('/rooms/{roomId}/images', [RoomImageController::class, 'index']);

    // Guests - All can view and create, Admin/Manager can modify
    Route::get('/guests', [GuestController::class, 'index']);
    Route::get('/guests/{id}', [GuestController::class, 'show']);
    Route::post('/guests', [GuestController::class, 'store']);
    Route::middleware('role:Admin,Manager')->group(function () {
        Route::put('/guests/{id}', [GuestController::class, 'update']);
        Route::delete('/guests/{id}', [GuestController::class, 'destroy']);
    });

    // Bookings - All authenticated users
    Route::post('/bookings/{booking}/check-in', [BookingController::class, 'checkIn']);
    Route::post('/bookings/{booking}/check-out', [BookingController::class, 'checkOut']);
    Route::post('/bookings/{booking}/cancel', [BookingController::class, 'cancel']);
    Route::apiResource('bookings', BookingController::class);

    // Payments - All authenticated users
    Route::apiResource('payments', PaymentController::class);

    // Services - Admin and Manager can modify, all can view
    Route::middleware('role:Admin,Manager')->group(function () {
        Route::post('/services', [ServiceController::class, 'store']);
        Route::put('/services/{id}', [ServiceController::class, 'update']);
        Route::delete('/services/{id}', [ServiceController::class, 'destroy']);
    });
    Route::get('/services', [ServiceController::class, 'index']);
    Route::get('/services/{id}', [ServiceController::class, 'show']);
    Route::post('/services/add-to-booking', [ServiceController::class, 'addToBooking']);

    // Reviews - All authenticated users
    Route::get('/reviews/booking/{bookingId}', [ReviewController::class, 'getByBooking']);
    Route::get('/reviews/guest/{guestId}', [ReviewController::class, 'getByGuest']);
    Route::apiResource('reviews', ReviewController::class);

    // Notifications - Admin only
    Route::middleware('role:admin')->group(function () {
        Route::get('/notifications', [NotificationController::class, 'index']);
        Route::post('/notifications/read-all', [NotificationController::class, 'markAllAsRead']);
        Route::post('/notifications/{id}/read', [NotificationController::class, 'markAsRead']);
        Route::delete('/notifications/{id}', [NotificationController::class, 'destroy']);
    });

    // Discounts/Promo Codes - Admin and Manager
    Route::middleware('role:Admin,Manager')->group(function () {
        Route::apiResource('discounts', DiscountController::class);
    });
    Route::post('/discounts/validate', [DiscountController::class, 'validate_code']);
    Route::get('/discounts', [DiscountController::class, 'index']);

    // Users - Admin only
    Route::middleware('role:admin')->group(function () {
        Route::apiResource('users', UserController::class);
        Route::apiResource('roles', RoleController::class);
    });
});

// Invoices - Generate and download PDFs (auth required)
Route::middleware('auth:sanctum')->group(function () {
    Route::get('/invoices/booking/{bookingId}', [InvoiceController::class, 'generateBookingInvoice']);
    Route::get('/invoices/payment/{paymentId}', [InvoiceController::class, 'generatePaymentReceipt']);
    Route::get('/invoices/preview/booking/{bookingId}', [InvoiceController::class, 'previewBookingInvoice']);
    Route::get('/invoices/preview/payment/{paymentId}', [InvoiceController::class, 'previewPaymentReceipt']);
});

// Guest Portal Routes (separate auth guard)
Route::prefix('guest')->middleware(['auth:sanctum', 'sanctum.guest'])->group(function () {
    Route::post('/logout', [GuestAuthController::class, 'logout']);
    Route::get('/me', [GuestAuthController::class, 'me']);

    // Guest profile update
    Route::put('/profile', [GuestAuthController::class, 'updateProfile']);

    // Guest's own bookings and reviews
    Route::get('/my-bookings', [GuestAuthController::class, 'myBookings']);
    Route::get('/my-reviews', [GuestAuthController::class, 'myReviews']);

    // Guest can create bookings
    Route::post('/bookings', [BookingController::class, 'store']);

    // Guest can view available rooms
    Route::get('/rooms/available', [RoomController::class, 'available']);

    // Guest can view their payments
    Route::get('/payments', [PaymentController::class, 'guestPayments']);
});
