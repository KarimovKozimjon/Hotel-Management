<?php
// payment.php config removed. Payment systems are disabled.
